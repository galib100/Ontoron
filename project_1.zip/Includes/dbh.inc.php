<?php
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "ontoron";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbname);
