

<!-- footer section -->
<section id="ftsection" class="text-center ">
 <div class="container bg-dark text-light py-4">
 <p>copyright 2020 <span >&copy;</span> Ontoron</p>
 </div>
</section>


  </body>
   <script href="js/bootstrap.min.js"></script>
   <script href="js/popper.min.js"></script>
</html>
